/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ntshapha
 */
import java.sql.*;
import javax.swing.*;
public class javaconnect 
{
    Connection conn=null;
    public static Connection connecrDb()
    {
        try{
            Connection conn=DriverManager.getConnection("jdbc:sqlite:C:\\Users\\21339\\OneDrive\\Documents\\NetBeansProjects\\BadDay\\BadDay.db");
            //C:\Users\21339\OneDrive\Documents\NetBeansProjects\BadDay
            //JOptionPane.showMessageDialog(null,"Connection Established");
            return conn;
        }
        
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
            return null;
        }
       
    }
}
